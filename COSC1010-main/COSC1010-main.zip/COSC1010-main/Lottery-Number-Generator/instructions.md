# Instructions  

Design a program that generates a seven-digit lottery number. The program should generate seven random numbers, each in the range of 0 through 9, and assign each number to a list element. (Random numbers were discussed in Chapter 5.) Then write another loop that displays the contents of the list.

Review [The Lottery Number Generator Problem](https://mediaplayer.pearsoncmg.com/assets/_video.true/Lottery_Number_Generator_Problem) VideoNotes. You will see the output you should have for this programming challenge as well as the code.