#
# Name
# Date
# Sales Tax Programming Project
# COSC 2409 DNT
#

# Variable declarations

# Constants for the state and county tax rates

# Get the amount of the purchase.

# Calculate the state sales tax.

# Calculate the county sales tax.

# Calculate the total tax.

# Calculate the total of the sale.

# Print information about the sale.
