#
# Name
# Date
# Your First Python Program
# COSC 1010 
#

# This is my first Python program.
