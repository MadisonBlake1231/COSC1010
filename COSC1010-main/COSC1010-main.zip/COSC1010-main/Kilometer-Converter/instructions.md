# Instructions  

Write a program that asks the user to enter a distance in kilometers, then converts that distance to miles. The conversion formula is as follows: *Miles = Kilometers x 0.6214*

Review [The Kilometer Converter Problem](https://mediaplayer.pearsoncmg.com/assets/_video.true/The_Kilometer_Converter_Problem) VideoNotes. You will see the output you should have for this programming challenge as well as the code.
 