#
# Name
# Date
# Areas of Rectangles Programming Project
# COSC 2409 DNT
#
# Local variables

# Get length A

# Get width A

# Get length B

# Get width B

# Calculate area A

# Calculate area B

# Print area comparison using if-elif-else statements
