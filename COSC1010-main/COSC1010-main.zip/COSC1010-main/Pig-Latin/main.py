#
# Name
# Date
# Pig Latin Programming Project
# COSC 1010
#
# Use comments liberally throughout the program. 