# Instructions  

Modify the program that you wrote for `Average of Numbers` so it handles the following exceptions:

- It should handle any `IOError` exceptions that are raised when the file is opened and data is read from it.

- It should handle any `ValueError` exceptions that are raised when the items that are read from the file are converted to a number. 